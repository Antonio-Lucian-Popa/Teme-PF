import Data.Char (isDigit, digitToInt)

nrVocale :: [String] -> Int
nrVocale lst = sum $ map countVowels $ filter isPalindrome lst

isPalindrome :: String -> Bool
isPalindrome s = s == reverse s

countVowels :: String -> Int
countVowels s = length $ filter (`elem` "aeiouAEIOU") s

adaugaDupaPar :: Int -> [Int] -> [Int]
adaugaDupaPar _ [] = []
adaugaDupaPar n (x:xs)
    | even x    = x : n : adaugaDupaPar n xs
    | otherwise = x : adaugaDupaPar n xs


divizori :: Int -> [Int]
divizori n = [x | x <- [1..n], n `mod` x == 0]

listadiv :: [Int] -> [[Int]]
listadiv = map divizori

inIntervalRec :: Int -> Int -> [Int] -> [Int]
inIntervalRec _ _ [] = []
inIntervalRec low high (x:xs)
    | low <= x && x <= high = x : inIntervalRec low high xs
    | otherwise = inIntervalRec low high xs

inIntervalComp :: Int -> Int -> [Int] -> [Int]
inIntervalComp low high lst = [x | x <- lst, low <= x && x <= high]

pozitiveRec :: [Int] -> Int
pozitiveRec [] = 0
pozitiveRec (x:xs)
    | x > 0 = 1 + pozitiveRec xs
    | otherwise = pozitiveRec xs

pozitiveComp :: [Int] -> Int
pozitiveComp lst = length [x | x <- lst, x > 0]

pozitiiImpareRec :: [Int] -> [Int]
pozitiiImpareRec = helper 0
  where
    helper _ [] = []
    helper idx (x:xs)
        | odd x = idx : helper (idx + 1) xs
        | otherwise = helper (idx + 1) xs

pozitiiImpareComp :: [Int] -> [Int]
pozitiiImpareComp lst = [idx | (x, idx) <- zip lst [0..], odd x]

multDigitsRec :: String -> Int
multDigitsRec [] = 1
multDigitsRec (x:xs)
    | isDigit x = digitToInt x * multDigitsRec xs
    | otherwise = multDigitsRec xs

multDigitsComp :: String -> Int
multDigitsComp str = product [digitToInt x | x <- str, isDigit x]
