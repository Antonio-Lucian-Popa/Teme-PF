import Data.Char
import Data.List

sigma :: Integer -> Integer -> (Integer -> Integer) -> Integer
sigma min max f
  | min == max  = f min
  | min < max = (f min) + (sigma (min+1) max f)
  | min > max = 0

f :: Integer -> Integer
f x = 100 * x + 1

fact :: Integer -> Integer
fact 0 = 1
fact n = n * (fact (n-1))

fact2fn :: Integer -> Integer
fact2fn n
  | n < 0 = 0
  | n == 0 = 1
  | n > 0 = n * (fact2fn (n-1))

fact2 :: Integer -> Integer
fact2 n
  | n < 0 = 0
  | n == 0 = 1
  | n > 0 = n * fact2 (n - 1)

dan :: Integer -> (Integer -> Integer)
dan n = \_ -> n

dan2 :: Integer -> (Integer -> Integer)
dan2 n _ = n
