import Data.List

myInt = 5555555555555555555555555555555555555555555555555555555555555555555555555555555555555

double :: Integer -> Integer
double x = x+x


--maxim :: Integer -> Integer -> Integer
maxim x y = if (x > y)
               then x
          else y

max3 x y z = let
             u = maxim x y
             in (maxim  u z)

triple :: Integer -> Integer
triple x = x * 3


maxim4 :: Integer -> Integer -> Integer -> Integer -> Integer
maxim4 x y z w = let
              u = maxim x y
              v = maxim z w
              in maxim u v

testMaxim4 :: Integer -> Integer -> Integer -> Integer -> Bool
testMaxim4 x y z w = let
              maxVal = maxim4 x y z w
              in (maxVal >= x) && (maxVal >= y) && (maxVal >= z) && (maxVal >= w)



sumaPatrate :: Integer -> Integer -> Integer
sumaPatrate x y = x^2 + y^2

parSauImpar :: Integer -> String
parSauImpar x = if even x then "par" else "impar"

factorial :: Integer -> Integer
factorial 0 = 1
factorial n = n * factorial (n - 1)

maiMareDecatDublul :: Integer -> Integer -> Bool
maiMareDecatDublul x y = x > 2 * y
