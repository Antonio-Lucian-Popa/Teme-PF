import Data.Char
import Data.List


-- 1.
rotate :: Int -> [Char] -> [Char]
rotate n xs
    | n < 0 || n > length xs = error "Index out of bounds"
    | otherwise = drop n xs ++ take n xs


-- 2.
prop_rotate :: Int -> String -> Bool
prop_rotate k str = rotate (l - m) (rotate m str) == str
                        where l = length str
                              m = if l == 0 then 0 else k `mod` l

-- 3.
makeKey :: Int -> [(Char, Char)]
makeKey n = zip ['A'..'Z'] (rotate n ['A'..'Z'])

-- 4.
lookUp :: Char -> [(Char, Char)] -> Char
lookUp ch pairs = case lookup ch pairs of
    Just val -> val
    Nothing -> ch

-- 5.
encipher :: Int -> Char -> Char
encipher n ch = lookUp ch (makeKey n)

-- 6.
normalize :: String -> String
normalize = filter (\x -> elem x (['A'..'Z'] ++ ['0'..'9'])) . map toUpper
    where toUpper ch = if elem ch ['a'..'z'] then chr (ord ch - 32) else ch

-- 7.
encipherStr :: Int -> String -> String
encipherStr n = map (encipher n) . normalize

-- 8.
reverseKey :: [(Char, Char)] -> [(Char, Char)]
reverseKey = map (\(a, b) -> (b, a))

-- 9.
decipher :: Int -> Char -> Char
decipher n ch = lookUp ch (reverseKey (makeKey n))

decipherStr :: Int -> String -> String
decipherStr n = map (decipher n) . filter (\x -> elem x (['A'..'Z'] ++ ['0'..'9'] ++ [' ']))
