import Data.Char
import Data.List

data Tree a = Leaf a
            | Branch (Tree a) (Tree a)
            deriving (Ord, Show, Eq)

data Arbore a = Frunza a
              | Ramificatie (Arbore a) (Arbore a)
              deriving (Ord, Show, Eq)


a1 = Frunza 'X'
a2 = Frunza 1001
a3 = Ramificatie (Frunza 1) (Frunza 2)
a4 = Ramificatie a3 a3
a5 = Ramificatie (Frunza 10) a3

tunde :: Arbore a -> [a]
tunde (Frunza a) = [a]
tunde (Ramificatie ram1 ram2) = tunde ram1 ++ tunde ram2
