lungime:: [e] -> Integer
lungime [] = 0
lungime (h:t) = 1 + lungime t

cap :: [e] -> e
cap (h:t) = h

coada:: [e] -> [e]
coada (h:t)= t

-- Cap3Par4Ex1.hs

-- Nivel de prioritate 5, Asoc la dreapta.
infixr 5 :::
data Lista a = ListaVida
             | a ::: (Lista a)
             deriving (Show, Ord, Eq)

lung:: Lista a -> Integer
lung ListaVida = 0
lung (a ::: lis)= 1 + lung lis

-- O functie care aplica o alta fct pe o Lista
mapping:: (a -> b) -> [a] -> [b]
mapping       f       []    = []
mapping       f      (h:t) = f h : mapping f t


ultim:: [a] -> a
ultim (x : []) = x
ultim (h:t)    = ultim t

element :: Integer -> [a] -> a
element       0   _   = error "Incepem de la 1!"
element       1       (h:t) = h
element       n       (h:t) = element (n-1) t
element       _   _      = error "Nu stiu ce sa fac!"

-- Puteti simula calcule cu erori
-- fara sa opriti programul
-- folosind tipul compus Maybe x
-- unde x este alt tip

plus :: Maybe Int -> Maybe Int -> Maybe Int
plus (Just x) (Just y) = Just (x+y)
plus Nothing _ = Nothing
plus _ Nothing = Nothing

-- f aaaaa []
-- f aaaa  [b]
-- f aa    [bb]
-- f a     [bbb]

-- rl [1,2,7] []
-- rl [2,7]   [1]
-- rl [7]     [2,1]
-- rl []      [7,2,1]

-- rev [a] accum rezultat
rl:: [a] -> [a] -> [a]
rl []   rezultat = rezultat
rl (h:t) lista   = rl t (h:lista)

revers :: [a] -> [a]
revers lista = rl lista []

-- O solutie banala, dar fara acc.

rev :: [a] -> [a]
rev [] = []
rev [x] = [x]
rev (h:t) = (rev t) ++ [h]

-- Transformarea unui string in nr
-- intai am transformat un caracter din string
valc:: Char -> Integer
valc '0' = 0
valc '1' = 1
valc '2' = 2
valc '3' = 3
valc '4' = 4
valc '5' = 5
valc '6' = 6
valc '7' = 7
valc '8' = 8
valc '9' = 9

-- Transform sirul de caractere in numar
-- inmultesc cu 10 si adaug valoarea cifrei
valli:: [Char] -> Integer
valli []= 0
valli [a] = valc a
valli (h:t) = valc h + 10 * valli t

atoi:: [Char] -> Integer
atoi l= valli (revers l)
