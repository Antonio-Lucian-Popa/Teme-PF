firstEl :: [(a, b)] -> [a]
firstEl = map fst

sumList :: [[Int]] -> [Int]
sumList = map sum

prel2 :: [Int] -> [Int]
prel2 = map (\x -> if even x then x `div` 2 else x * 2)

filterStrings :: Char -> [String] -> [String]
filterStrings ch = filter (elem ch)

oddSquares :: [Int] -> [Int]
oddSquares = map (^2) . filter odd

oddPositionSquares :: [Int] -> [Int]
oddPositionSquares lst = [x^2 | (x, i) <- zip lst [0..], odd i]

numaiVocale :: [String] -> [String]
numaiVocale = map (filter (`elem` "aeiouAEIOU"))

mymap :: (a -> b) -> [a] -> [b]
mymap f = foldr ((:) . f) []

myfilter :: (a -> Bool) -> [a] -> [a]
myfilter p = foldr (\x acc -> if p x then x : acc else acc) []

sumOddSquares :: [Int] -> Int
sumOddSquares = sum . map (^2) . filter odd

allTrue :: [Bool] -> Bool
allTrue = foldr (&&) True


rmChar :: Char -> String -> String
rmChar ch = filter (/= ch)

rmCharsRec :: String -> String -> String
rmCharsRec [] str = str
rmCharsRec (c:cs) str = rmCharsRec cs (rmChar c str)

rmCharsFold :: String -> String -> String
rmCharsFold chars str = foldr rmChar str chars
