poly2 :: Double -> Double -> Double -> Double -> Double
poly2 a b c x = a * x^2 + b * x + c

eeny :: Integer -> String
eeny x = if even x then "eeny" else "meeny"


fizzbuzzIf :: Integer -> String
fizzbuzzIf x =
    if x `mod` 15 == 0 then "FizzBuzz"
    else if x `mod` 3 == 0 then "Fizz"
    else if x `mod` 5 == 0 then "Buzz"
    else ""


fizzbuzzGuards :: Integer -> String
fizzbuzzGuards x
    | x `mod` 15 == 0 = "FizzBuzz"
    | x `mod` 3 == 0 = "Fizz"
    | x `mod` 5 == 0 = "Buzz"
    | otherwise = ""



fibonacciCazuri :: Integer -> Integer
fibonacciCazuri n
    | n < 2     = n
    | otherwise = fibonacciCazuri (n - 1) + fibonacciCazuri (n - 2)
fibonacciEcuational :: Integer -> Integer
fibonacciEcuational 0 = 0
fibonacciEcuational 1 = 1
fibonacciEcuational n =
    fibonacciEcuational (n - 1) + fibonacciEcuational (n - 2)


tribonacciCases :: Integer -> Integer
tribonacciCases n
    | n == 0 = 0
    | n == 1 = 1
    | n == 2 = 1
    | otherwise = tribonacciCases (n - 1) + tribonacciCases (n - 2) + tribonacciCases (n - 3)


tribonacciEquational :: Integer -> Integer
tribonacciEquational 0 = 0
tribonacciEquational 1 = 1
tribonacciEquational 2 = 1
tribonacciEquational n = tribonacciEquational (n - 1) + tribonacciEquational (n - 2) + tribonacciEquational (n - 3)



binomial :: Integer -> Integer -> Integer
binomial n k
    | k == 0 = 1
    | n == 0 = 0
    | otherwise = binomial (n - 1) k + binomial (n - 1) (k - 1)


verifL :: [Int] -> Bool
verifL lst = even (length lst)

takefinal :: [a] -> Int -> [a]
takefinal lst n = drop (length lst - n) lst

remove :: [a] -> Int -> [a]
remove lst n = take (n - 1) lst ++ drop n lst


myreplicate :: Int -> a -> [a]
myreplicate n v
    | n <= 0    = []
    | otherwise = v : myreplicate (n - 1) v


sumImp :: [Int] -> Int
sumImp [] = 0
sumImp (x:xs)
    | odd x     = x + sumImp xs
    | otherwise = sumImp xs


totalLen :: [String] -> Int
totalLen [] = 0
totalLen (x:xs)
    | head x == 'A' = length x + totalLen xs
    | otherwise     = totalLen xs




-- semiPareRec [0,2,1,7,8,56,17,18] == [0,1,4,28,9]
semiPareRec :: [Int] -> [Int]
semiPareRec [] = []
semiPareRec (h:t)
 | even h    = h `div` 2 : t'
 | otherwise = t'
 where t' = semiPareRec t
