factori :: Int -> [Int]
factori n = [x | x <- [1..n], n `mod` x == 0]

prim :: Int -> Bool
prim n = n > 1 && (factori n == [1, n])

numerePrime :: Int -> [Int]
numerePrime n = filter prim [2..n]


myzip3 :: [a] -> [b] -> [c] -> [(a, b, c)]
myzip3 (x:xs) (y:ys) (z:zs) = (x, y, z) : myzip3 xs ys zs
myzip3 _ _ _ = []


ordonataNat :: [Int] -> Bool
ordonataNat (x:y:xs) = x <= y && ordonataNat (y:xs)
ordonataNat _ = True

ordonata :: (a -> a -> Bool) -> [a] -> Bool
ordonata _ [] = True
ordonata _ [_] = True
ordonata rel (x:y:xs) = rel x y && ordonata rel (y:xs)

infixr 6 *<*
(*<*) :: (Integer, Integer) -> (Integer, Integer) -> Bool
(*<*) (a, b) (c, d) = a < c || (a == c && b < d)

compuneList :: (b -> c) -> [(a -> b)] -> [(a -> c)]
compuneList f = map (f .)

aplicaList :: a -> [(a -> b)] -> [b]
aplicaList x fs = [f x | f <- fs]
